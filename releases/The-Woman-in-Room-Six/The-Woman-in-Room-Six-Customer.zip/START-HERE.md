# The Woman in Room Six

Porch Press • Edition 1.1 • Fictional printable genealogy mystery

Open **Player.pdf** first. Its 38 pages contain the story opening, archive catalog, 24 exhibits, four investigation packets, and writing space. Read Packet A and write your provisional findings before moving to B, then C, then D. Work alone or share the investigation with a small group.

**Optional help:** Hints.pdf has five pages. Read only the page for your current packet and reveal one hint level at a time.

**Keep closed until finished:** SEALED-Solution.pdf is eight pages, including evidence-cited findings and the human aftermath. READ-AFTER-PLAY-Complete-Story.pdf is the 16-page companion story and includes the resolution. Neither is an additional puzzle you must solve.

## Print and play

- US Letter: actual size / 100%. A4: Fit.
- Color is optional. Investigative text is readable in grayscale.
- Print Player.pdf, or read it on screen and use paper for notes. The cover is optional.
- Single-sided printing is easiest for laying out records. Duplex is usable; the player file contains no separately sealed answer section.
- Print hints and solution separately so answers do not appear on the reverse of evidence. Do not print every file unless you want paper copies of the optional material.
- A pencil and ordinary paper are all you need. No host, scissors, website, subscription, or genealogy account is required.

The customer download contains four PDFs and this START-HERE file. It is a digital product; no physical item is shipped. All characters, institutions, case records, and named communities are fictional. Historical record types inform the design, but these pages are not authentic scans.

Personal use: print copies for your own household or private play group. Do not redistribute, resell, or upload the files publicly.
