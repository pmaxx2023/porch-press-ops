# The Wrong Widow - current author source

Authorship and release authority: Owner_Bot. Complete canon, trail, packet builder, and proof source for edition 1.0. Extract together and run python3 packet/build_packet.py with ReportLab installed. The builder resolves canon and trail relative to itself.

Current approved storefront/ad copy is maintained once under marketing/The-Wrong-Widow in the repository; duplicate earlier pitch copy is excluded from this source ZIP. Read the root ASSET_INDEX.md for current selection and verification limits. Stage reports preserve evidence of performed checks; their historical task-status language does not supersede the current index. No human playtest or paid retrieval is asserted.
