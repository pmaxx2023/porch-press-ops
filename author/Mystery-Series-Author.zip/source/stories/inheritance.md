# The Inheritance

## opening|The keys on Ruth's desk|Before the opening brief

Ruth Fenwick put the mill keys on a folded cloth. She had discovered that leaving them in sight made people speak to the keys instead of to her. Putting them away made people ask where they were. There seemed to be no neutral place for an inheritance.

Nell Mercer arrived with papers she had tried to keep flat. Arthur's papers were already arranged. Clara Whitcomb paused at the doorway until Ruth moved a chair out for her.

"We could have settled the family part ourselves," Arthur said.

Nell sat down. "Then you wouldn't have needed my papers."

He gave her the weary look of a brother being contradicted in company. Ruth saw Nell almost answer it with an apology. Instead she put her packet on the desk.

Clara kept her hands in her lap. She was the person easiest for the others to treat as an intrusion. Ruth asked her to move closer so she could see the will.

"I didn't choose my mother's name to inconvenience anyone," Clara said quietly.

Arthur looked embarrassed. Nell made room on the desk.

Henry Vale had left words that seemed simple until living people began placing themselves inside them. Earliest-born. Surviving. Child. The claimants could all tell stories about what a family ought to recognize. The document required a particular relationship and an order of birth.

"I am not asking which of you needs the property most," Ruth said. "Nor which of you can speak most confidently about it."

"It has to be managed," Arthur said.

"That is a different question."

Nell looked at the keys. She had not been offered the ease of treating the business as a foregone conclusion. Even being asked what she intended to do with it would have meant somebody believed she might have a claim.

Ruth turned the will so everyone could read. "You may dislike the result. I won't ask you to dislike it less. I will ask you to let the papers be checked."

Outside, the town's work went on. Inside, three people waited for an old man's language to determine which of their futures could become real. Ruth kept her hand beside the keys. Not on them. Nobody had yet earned an answer merely by reaching first.

## s1|A place in somebody else's house|After E03-E04

Nell followed the household names with her finger, stopping before it touched the ink. It was an odd experience to see a home flattened into a list. There was a head of household, then everyone else arranged by relationship to that head.

"People hear daughter and think they know the mother," she said.

Ruth let the observation stand without turning it into a conclusion. The schedule would have to be read alongside other records. Family familiarity could make a mistaken reading feel obvious.

Arthur drew his chair toward the desk. "Nobody is denying you were part of the family."

Nell looked at him. "That isn't the only question you've been answering for me."

He opened his mouth, then reached for his own claim instead. Ruth wondered whether he heard the difference between letting a sister belong and letting her have a claim that could defeat his. She could not certify what he understood. She could require him to support what he said.

Clara asked which Ada the will meant. For the first time, both siblings turned toward her as a person who had asked a useful question.

"The one it identifies," Ruth said, bringing the will nearer. "We must connect the entries."

Clara nodded. "Then connect mine too. Even if they lead away."

Nell looked at her and moved the census so Clara could see the whole page. It was a small alliance, not a promise to agree. They were both asking for their records to receive the same attention as Arthur's confidence.

The later addresses made the family harder to imagine as one familiar room. People married, worked, moved, and appeared under names that would make sense in one record and obscure them in another. A daughter could leave a house without leaving her ancestry. A shared surname could invite recognition the parents' names did not sustain.

Ruth set a clean comparison sheet between the claimants. "Write down what would prove your claim," she said. "And what would disprove it."

Nobody reached for the pencil immediately.

## s2|The cost of an easy name|After E05-E08

The burial index was the shortest paper on the desk. That made it tempting. The claimants had been reading dates and parents for long enough to want one line that settled something.

Arthur tapped the abbreviation, then stopped when Ruth looked at his hand.

"It's what I understood," he said.

"I have written that down as your understanding."

"You make it sound as if I invented it."

"No. I am asking what supports it."

Nell had spent much of the morning wanting Ruth to speak more sharply to him. Now she was relieved that she had not. A quarrel would let everyone remember the insult instead of the record. Whatever this entry meant, it belonged to a child, not merely to a claim that needed removing.

Clara looked from the baptismal names to her own parents' entry. "My mother was called Ada," she said. This time she did not offer it as an answer. It was a fact she had carried all her life, suddenly too small for the work she wanted it to do.

Nell understood the humiliation of having something intimate treated as insufficient. She also understood, unwillingly, that being hurt by the request did not make the request wrong.

Ruth placed the abbreviated burial entry beside its source reference. "An index helps us find a record. We still need the record."

Arthur leaned back. The full extract would take his explanation out of the territory of things the family had always said. It might confirm him. It might not. Ruth offered no prediction.

The marriage and baptismal entries had once served people who needed a union entered, a child named, a burial recorded. They had not been written to referee this room. Their indifference to the claimants' wishes was what made them useful.

Nell read the child's name again, this time in full. She did not yet write a conclusion beside it. She wanted the keys. She wanted, unexpectedly, not to become someone who could hurry a dead child out of the way merely because the page promised an advantage.

## s3|What a brother could offer|After E09-E14

Arthur tried to make the conversation private by lowering his voice. Ruth could still hear every word.

"Whatever happens, I wouldn't leave you without help," he told Nell.

She stared at him. The offer might have been sincere. Its sincerity was part of what angered her.

"You keep making a place for me after you've put yourself first."

"I'm trying to say we needn't fall out."

"Then let the order be checked without asking me to thank you."

Clara looked away, giving them the privacy the room could not. Ruth left the certificates where they lay. A sister's anger did not establish her birth order; a brother's generosity did not establish his. Neither feeling had to be false for the evidence to contradict a claim.

The fuller records required a slower comparison: names before marriage, named parents, exact dates, an age at burial, a school entry made for the practical business of knowing which child answered when called. Ordinary details survived where confident family shorthand had become unreliable.

Clara asked for her marriage extract back. "May I copy the reference?"

"Of course," Ruth said.

She wrote carefully. It was the first thing she had done all morning that was not directed at acquiring the property. Whatever the final answer, she would take away a properly identified record of her own family. Nell watched her and felt some of the room's urgency loosen. Losing a claim did not make a life a distraction.

Arthur had gone quiet. Nell could not tell whether he was reconsidering the documents or simply finding a more defensible way to remain certain. She would have to let his next action answer that.

Ruth drew the keys toward the center of the desk.

"Now," she said, "set out the line from the woman named in the will. Give me each connection. Give me the order. And show me which child the burial actually records."

Nell took up the pencil. For once she was being asked to make her case in full, rather than fit herself into a future somebody else had already described.

## aftermath|The name on the receipt|After the evidence-cited solution

Ruth wrote Ellen May Mercer on the receipt and then added Nell. She wanted the formal identity and the name its owner used to occupy the same line.

Nell signed before picking up the keys. Arthur watched the pen. He had spent the morning speaking of practical matters, but when the practical act arrived he had nothing ready to say.

Clara rose first. "You found the right Ada," she said.

Nell could not tell whether it was meant as congratulations. "And yours."

Clara looked down at the reference she had copied. "Yes."

Ruth put Clara's papers into their own folder. There was no reason for the rejected claim to be remembered as a ridiculous one, or for Ada Marsh to remain merely the woman who was not Ada Vale. No evidence in the file required deliberate deceit from Clara or Arthur. Their errors still had consequences.

Arthur offered to carry Nell's packet. She almost refused because refusing would feel like winning a little more. Then she handed him the heavier part and kept the receipt herself.

"You can help me read the practical papers," she said. "You can't answer for me."

He nodded once. It was too soon to know what he would make of the distinction.

At the threshold, Nell stopped. A set of keys had become hers by the terms Henry chose. It had not arrived because Ruth liked her, because her brother had underestimated her, or because she had suffered more than Clara. The records placed Ellen May ahead of Arthur, separated her from the infant Lucy Ellen, and connected her to Ada Vale. That was the proof. The rest was what she would have to live with.

She thought about the school entry's instruction to use the full name. To its writer, it had been a small precaution against confusion. Decades later, it had helped keep her from being mistaken out of her own life.

Ruth waited while she put the receipt inside the packet. "Will you need someone to go with you?"

"I may," Nell said. "I'll ask."

She was not promising to run a mill without advice, or to become instantly generous to everyone who had irritated her. She was reserving the right to decide whom she would ask and what she would accept. Arthur held the door. Nell walked through carrying the keys, and he followed when she was ready.
