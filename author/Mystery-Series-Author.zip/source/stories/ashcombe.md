# The Last Ashcombe

## opening|The house waiting|Before the opening brief

The house had been locked for six days, but people still spoke as though one of them already owned the silence inside it.

Lawrence stood nearest Harcourt's desk. He referred to the place as ours, then corrected himself to the family property. Celia noticed the correction because she had spent a lifetime hearing the first phrase and being expected to understand that it did not quite include her.

"There is no need for everyone to be kept waiting," Lawrence said.

Harcourt arranged the petitions in the order received. "Then we should begin with the settlement."

"We know what our grandfather intended."

"We have what he wrote."

Peter Vale smiled at that. Celia saw it and wondered how long his pleasure in careful wording would last if the words troubled his own claim.

She had brought a petition too. Putting her name on it had felt more exposed than she expected. She did not pretend Lawrence's place in the family could be wished away. She wanted her own place recorded correctly, and she wanted the rules read before confidence hardened into possession.

"You might at least trust me to see you properly provided for," Lawrence told her.

"I am asking you to let the papers be read."

He looked hurt. She knew that hurt could be sincere and still make it harder for her to insist. Since Edward's death, people had been particularly ready to offer advice in the shape of decisions already taken for her.

Peter laid his hand on his petition. "There is an elder branch."

Harcourt did not move the keys toward him. "Then we will follow it."

Celia looked through the window at the house. Somewhere in its everyday arrangements were people who had to turn up for work regardless of which claimant won. A settlement might transfer property at an exact instant. The people depending on that property would have to live through everything that followed.

She drew her chair close enough to read. The task was not to choose the most persuasive person in the room. It was to establish who belonged in the line, where that person stood, and who was alive when Julian died. Celia intended to listen even when the answer ceased to help her.

## s1|Being right about someone else|After E01-E03

Peter read the branch rule aloud. He sounded pleased with the settlement's refusal to reward the familiar surname merely for being familiar.

Lawrence interrupted. "The name has meant something to this house."

"The rule gives no preference for it," Peter said.

He was right about the wording. Celia could see how satisfying he found it to be right in front of Lawrence. She could also see Harcourt waiting until he finished before asking what established the rest of Peter's position.

Peter brought forward the references he relied on. His account had a path through the family, a death, a supposed ended line, a relinquishment. It sounded orderly. Harcourt treated each part as a separate claim to check.

"My mother signed," Peter said.

"We will read what she signed."

Lawrence began to object, then stopped. For a moment both men wanted the same thing: for one reassuring piece of family knowledge to be accepted without another trip through the files.

Celia asked to see the relinquishment with the settlement beside it. Peter gave her the copy. His expression suggested that sharing it ought to make her grateful to him. She thanked him for the paper, not for the conclusion.

"If it removes her," she asked Harcourt, "we still have to read what it says about those after her?"

"We have to read all of it."

Celia could not make herself uninterested in the result. She might lose by the same rule she insisted was worth following. That did not make the rule an insult to her.

Beyond the desk, a door opened and closed as the house's work continued. The petitioners' names were on the papers because they had petitioned. The settlement did not say that a person became a descendant only by entering this room and asking to be counted.

Harcourt set out the branch registers. Peter had challenged one easy assumption. Whether he had built his own claim on another was still a question for the records.

## s2|A note that became a certainty|After E04-E11

The word provisional was easy to read once Celia looked directly at it. She wondered how many times the note had been discussed without anyone pronouncing that word aloud.

Peter stared at the reference beneath it.

"It was in the papers," he said.

Harcourt did not dispute that. "So is the instruction to obtain the full record."

"I thought that had been done."

The room was quiet long enough for Celia to feel the temptation to enjoy his discomfort. He had enjoyed Lawrence's. There would be a certain symmetry to it. It would not help identify either child.

She moved the two certificates so their parents and addresses could be compared. "Then we can do it now."

Peter looked at her as if he had expected an accusation. She had one available, but not one the evidence yet justified. Relying on a mistaken note could be careless, self-serving, or deliberately dishonest. His claim register and the unfinished memorandum did not alone tell them which private explanation was true.

The full entries did have exact things to offer: a birth date, parents, a place, a source number. A child had died. Another child had been recorded as born. The similarity of their names had made it easy for one small life to be used to close another's line.

Lawrence leaned forward. "So his claim fails?"

Harcourt left his pen down. "We have not finished tracing the family."

Celia almost laughed, without pleasure. Each man could recognize the danger of a shortcut when it belonged to the other.

She thought of Alice's relinquishment, a signed act with a limited effect. People kept wanting papers to do more than their words did: turn a person's withdrawal into a branch's extinction, turn an index resemblance into a certified death, turn a trusted surname into a rule.

The next records would have to carry the identity forward. If the assumption was wrong, there might be someone to find. Celia felt the question change. It was no longer only where she herself stood. It was whether another person had been left waiting outside a conclusion nobody had properly checked.

## s3|The name on the wage line|After E12-E16

Ada Finch knew how a wage line could make a person seem smaller than the work she did. Employee 27. Name. Period. Amount. Signature. There was nothing improper about those columns. She depended on their being accurate.

It was the way people sometimes read them that troubled her, as if being entered under service meant she could appear nowhere else.

Harcourt asked her to look at the copies. Agnes Pike stayed nearby. Ada was grateful for a familiar person who did not fill every pause with an explanation of what she ought to feel.

"This is about the name?" Ada asked.

"It is about connecting the records correctly."

Her mother's marriage, her former surname, the request to change the payroll entry: ordinary arrangements returned to her as things strangers needed to examine. She had signed because the entry concerned her. She had not been writing a clue for someone else's inheritance dispute.

"You can ask me a question," she said. "You needn't discuss it over me."

Harcourt turned his chair toward her. "You're right."

It was a small correction, but Agnes watched him make it.

The duty record contained the exact time the settlement required. Ada remembered the work of that morning more readily than the significance other people now attached to the clock. Julian's death had been news carried into a room where people were already at work. For the claimants it had become an instant on which everything turned.

Celia stood at the doorway until Ada looked toward her. She did not offer congratulations, sympathy, or a prediction. None would have been fair before the line was established.

"They should get your name right," she said.

Ada studied her. "Yes. They should."

The register of branch bounds still had to be read with the earlier certificates. Identity was not, by itself, priority. Survival was not, by itself, entitlement. Harcourt gathered the copies so each link could be tested under the stated rules.

Ada asked for the papers to be explained to her when that work was done. She was accustomed to receiving instructions. This was a request to be included in the answer.

## aftermath|The question after the front door|After the original solution and continuation

After Ada entered by the front door, there was a silence in which everyone seemed to expect her to become a different kind of person.

She remained Ada Finch. She knew where the linen was kept and which passages led most quickly through the house. She did not suddenly know how to supervise a fund or distinguish useful advice from an attempt to take over her decisions.

Harcourt set the determination before her. Gideon, Frances, Robert, Ada. The first surviving eligible person in the eldest branch, alive at the fixed instant. Peter followed her; Lawrence and Celia came after him. Alice's registered act excluded Alice personally. It had not erased her son. Ada's changed surname had not erased Robert's child.

"I should like to read it myself," Ada said.

"Of course."

She heard the ease of that reply and wondered how much of it depended on what the determination had just made her. Agnes had respected her signature on the payroll before anyone followed it toward a settlement. Ada did not intend to forget the difference.

Celia waited while she read. Lawrence had questions about management. Peter had questions about the old note. They were questions someone would eventually need to address, but neither was permission to speak first for Ada.

"In a moment," she told them.

Peter looked at the memorandum. "I believed it."

Ada had no evidence requiring her to call that a lie. She also did not have to make him comfortable with the effect of believing it.

"You used it to say the line had ended."

He nodded. There was no quick repair available in the room.

Celia asked whether Ada wanted a chair nearer the window. Ada accepted. It was an offer she could answer without surrendering the rest of the conversation. Of the people who had hoped to inherit, Celia was the one giving her that much space.

The house would not become fair merely because a servant had been correctly identified as its successor. Wages, work, and dependence did not vanish at the front door. Ada had inherited the property under a fictional settlement, not proof that she would manage every part of it wisely.

She finished reading and asked Harcourt to show her what she would next be responsible for. Then she asked Agnes to sit down while they discussed it.
