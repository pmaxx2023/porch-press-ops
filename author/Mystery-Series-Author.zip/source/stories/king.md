# If I Were King

## opening|The unused cup|Before the opening brief

Daniel Wren put out two cups before remembering that he needed one. He left the second on the table. Taking it back to the shelf had become a small correction he could not always bear to make.

The letter from Veyr occupied Margaret's place.

He had read his own name in it several times. Daniel Wren, retired railway clerk. A man whose days had become quiet enough that the arrival of any post gave them a shape. The letter described a place in a succession. It did not offer the simple explanation for his life that he found himself wanting from it.

When Orme presented his declaration, Daniel listened longer than he might have listened to another man. Orme spoke as though there were still important tasks for him to perform, and as though experience at a railway desk might prepare him to do them well.

"You are accustomed to responsibility," Orme said.

Daniel looked at the two cups. "Some kinds."

Orme did not ask about the second. He put the paper where Daniel could sign it.

There was comfort in being given a line to complete. Daniel had spent a working life understanding which forms had to precede which decisions. The private declaration looked like another gate a sensible man should pass through without making trouble.

He reached for the pen, then drew the official letter nearer instead. Its warning about agents and authority was less flattering than Orme's account of him. It also had a seal and a reference he could check.

"I should like to read the earlier papers."

"Of course. There is the deadline to consider."

Daniel felt the pressure at once: asking to understand could be made to sound like refusing to act. He had not expected the possibility of a crown to resemble an awkward afternoon over a form.

"Then I ought to begin reading," he said.

Orme waited. Daniel had to resist filling the silence with an apology.

The second cup remained on the table after the papers were opened. Daniel could not ask Margaret whether the news would have amused or troubled her. He could look at the records of both families and refuse, for the moment, to let a stranger decide which of them mattered.

## s1|A life described as a branch|After K03-K09

Daniel knew how strange a familiar name could look in an unfamiliar column. Margaret was his wife. In the papers from Veyr, she was also a point in a line of descent, connected backward through names he had never needed to compare this carefully.

The settlement did not remember their marriage as he did. It needed birth order, parentage, survival, and the way a branch was to be followed. A spouse could stand beside someone through a life without becoming that person's descendant. The distinction was plain in the rule and oddly painful at the table.

"The papers have no feeling for it," he said.

Orme arranged a page squarely against another. "They are intended to bring certainty."

Daniel wondered how often he himself had sounded like that behind a counter. He had not always meant to be unkind. A man could become attached to a procedure because it allowed him to finish a day without carrying every applicant's life home.

He read the names again. A marriage changed one surname. A registered change altered another. Neither entry gave permission to turn the people into strangers merely because a later record called them something else.

Orme asked whether the family information was now sufficient for the declaration.

"Sufficient for which sentence?" Daniel asked.

The question surprised him. Until that morning he had been treating the signature as a single act. The paper contained separate assertions. Each would have to be true, not merely convenient to sign together.

Orme's answer was practiced. He could explain the orderly course the declaration would allow. He was less eager to leave a course open that it might obstruct.

Daniel set the unsigned paper aside. Margaret's family could not be reduced to the part that served his own position. Nor could his father's former surname be treated as the end of a line merely because the name was no longer used at home.

He put two headings on a clean sheet. Two branches. Under each, space for the connections the actual documents could prove.

## s2|The notice he believed|After K10-K13

Daniel recognized his own penciled words before he finished reading the notice.

Our Anna. Margaret must be told gently.

He had once thought the difficult part was how to carry the news from a piece of paper to his wife. The handwriting preserved that effort. It did not show him checking whether the paper identified their child.

For a moment the old urgency returned so completely that he wanted to put the notice face down. He could not bear to make the comparison. He could not bear the thought of declining to make it again.

"You were given an account," Orme said.

Daniel looked up. It sounded like absolution offered before he knew what had gone wrong.

"I made it into ours."

That was the part his pencil established. It did not establish who sent the notice to the wrong place, whether anyone intended harm, or what every institution had known. Those would be tempting stories to build around the shame he now felt. The supplied papers had more limited things to say.

The birth entry, care record, and death registration had fields the notice lacked. Daniel moved them close enough to compare without lifting his eyes far from the table.

He thought of Margaret's illness as something they had lived through, not as permission for an office to stop looking carefully at their child. He also thought of all the forms on which he had once accepted a familiar number before checking the rest of the line.

"No one can be expected to know everything," Orme said.

"No," Daniel answered. "But now I have these."

Hope was frightening enough that he would not name it yet. A mismatch was a reason to investigate, not a promise that every loss would be reversed. Somewhere beyond these pages there might be another record, another name, another person who had built an entire life without his questions in it.

He would not use that possibility to excuse himself. He would not let fear of being mistaken keep him from following it.

## s3|The convenient version|After K14-K18

By the time Daniel reached the private office memorandum, he had learned to distrust the relief of a quick answer. Even so, the instruction to secure his declaration before the other papers arrived made him feel foolish in a fresh way.

Orme had offered a path on which Daniel could remain the central person. The missing information would have made that path harder to control.

"You wanted me to sign what your own office had reason to question," Daniel said.

Orme began to speak of complications. He spoke as a man who could imagine the work ahead: competing papers, correspondence, an inconvenient person with an independent life. Daniel could understand an administrator preferring one manageable claimant. Understanding made the act more ordinary, not less disturbing.

"You called it helping me."

"I was trying to obtain a clear result."

Daniel looked down at the teacher's reply. A woman had continued living and working while other people considered whether her existence should complicate their arrangements. She was not a blank space waiting to improve his story.

The surviving records had to be linked: birth, care entry, transfer, change of name, marriage, present identity. Then the settlement had to be applied. Daniel could not move someone up the order because he wanted a reunion, any more than Orme could move someone out of it for convenience.

He placed the official correspondence apart from Orme's private papers. "These will go to the legation directly."

He had not yet written the account. He still needed to set it out so another reader could test each connection. That work felt more like responsibility than the title had.

The unused cup caught his eye. He had been imagining what the news could give him: a purpose, a name in a foreign court, perhaps an answer to a grief he had stopped questioning. Now there was another person's right to hear the truth and decide what contact she wanted.

Daniel put the pen beside a clean sheet. The next signature would need to follow an account he could support.

## aftermath|A letter without a title|After the original solution and ending

Daniel read his letter again before folding it. Dear Irene. He had written that name with more care than any of the titles supplied in the papers from Veyr.

The evidence placed Irene Moss, formerly Irene Alder and born Anna Wren, first through Margaret's senior branch. Daniel remained second through his own paternal line. Wanting to be a father did not determine the succession. Wanting him to be the convenient claimant did not erase a living descendant. Those were conclusions the records and settlement could support.

What Irene might say to him was another kind of question.

He could send the notice he had believed. He could explain his pencil beside it. He could provide the care and identity records so she could test what he claimed rather than trust an unknown man's longing. None of that entitled him to be welcomed.

He almost added that he and Margaret had suffered too. Then he left the sentence out. It was true that grief had shaped their lives. It was not Irene's first duty, on hearing his account, to comfort him for it.

He wrote that she could choose whether they met.

The words felt insufficient, and he let them remain insufficient. A promise to accept her choice would have to be kept later, when there was an actual choice to accept. Writing it could not complete that work in advance.

Beside the letter lay the papers for the legation. Orme's declaration was still unsigned. Daniel had separated what the case proved about the present suppression from what it did not prove about the old mistaken notice and the description of the birth parents as untraced. He would not make an accusation against everyone in an institution merely because one man's later conduct was demonstrably dishonest.

There was satisfaction in that restraint, but no escape from responsibility. His own annotation was still his. Checking now did not mean he had checked then.

He put the second cup back on the shelf that evening. He did not set it aside for Irene. She had a house, a profession, a husband, a life that was not waiting in Margaret's chair. If she came, he could ask what she wanted and take down another cup.

A reply might come. Until it did, Daniel would have to live with the question he was putting in another person's hands. He could supply the evidence, refuse the convenient falsehood, and ask for contact. Whether she wanted to call him Father was hers to decide.
