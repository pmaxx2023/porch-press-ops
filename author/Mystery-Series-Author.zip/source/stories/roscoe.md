# Roscoe's Grave

## opening|Before the chisel|Before the opening brief

Ada Reeve wanted her mother's name cut neatly, deeply enough to last. After the funeral there had been so many questions with small answers: which papers to keep together, which address to give, what wording to send the mason. She had been grateful for a task that seemed to have an end.

At Holt & Son, the order lay ready. Edith beside Roscoe. A family's ordinary completion.

Then the surname in the burial index stopped the work.

"Cross," Ada said. "That isn't my father's name."

The mason did not answer immediately. He had a job waiting and a bereaved customer in front of him. Neither made the discrepancy easier to explain.

"We could leave the existing inscription as it stands and add your mother."

"And the other name?"

He turned the order a little, as though an adjustment of paper might create a simpler question. "The office may have copied it wrongly."

At the records desk, Lydia Ames would not agree that it was an error before she had traced it. Ada found that irritating. She had come to finish something for Edith, not open another set of drawers.

"My mother knew where she meant to be buried," Ada said.

"Then we should follow the instructions she left."

"This is following them."

Lydia put the index beside the order. "It may be. Let us make sure we haven't mistaken an inscription for a burial entry."

Ada heard a correction when she needed condolences. She almost gathered up the papers. Instead she asked Lydia to show her the line again.

Her father's name on the stone was one of the fixed things in her life. The sea had taken him; the memorial had given the family somewhere to stand. She had not expected a clerical surname to disturb that arrangement years later.

But somebody had occupied the line in the book. If the book was wrong, Ada wanted it corrected. If it was right, she wanted to know whom her tidy addition would pass over.

She went back to the mason and asked him to wait. He looked at the unfinished order, then crossed out no names at all.

## s1|The person inside an initial|After R01-R06

Three similar names made Ada impatient with the index and with herself. She had arrived certain that a family grave must be a simple thing to identify. Now she was following references that looked capable of leading into three different lives.

Lydia brought the transfer accounts to the table. "We can compare the references before we decide what the surname means."

Ada glanced at the numbered seals. "You make it sound like a parcel."

"I know. These are the records of the arrangements. That is what they can tell us."

The answer annoyed Ada less than reassurance would have. Lydia had not promised that a paper chain was a physical examination. She was refusing to claim more certainty than the office possessed.

Ada copied the numbers. She checked the plot, the death registration, and the interment reference separately. A woman who had first appeared as an inconvenient initial began to have a full name and a history that extended beyond Ada's own family story.

At the mason's, Holt asked whether he should keep the proposed wording ready.

"Keep it," Ada said. "Don't cut it."

"Your mother is the part we know."

"She isn't the only person whose name would be on the stone."

He looked at her, then at the order. "No. She isn't."

Ada had wanted his impatience to be heartlessness. It would have given her a straightforward person to oppose. Instead he was a man accustomed to making a bereaved family's choice permanent, trying to get her to the point at which a choice could be made. His haste still mattered. It could still leave someone out.

Back at the desk, Lydia set the full entry where Ada could reach it without leaning across the other papers. She did not interpret the family relationship for her. The record supplied parents, a former surname, a spouse, an address. Those were routes into another set of records.

Ada kept the initial on her worksheet and wrote the full names underneath. Whatever had happened here, she would not solve it by making the least familiar person disappear first.

## s2|What the sea did not return|After R07-R08

Ada read the old stone order once, and then again more slowly. She had spent so much of her life seeing an inscription that she had given it powers no inscription possessed.

The shipping account was less consoling. Wreckage. A concluded search. No identifiable remains recovered. It told her what the search had found and what it had failed to bring home. It did not give her the last moment of her father's life.

"Did Mother think this was enough?" she asked.

Lydia stood beside the table. "I can't tell you what she thought."

Ada wanted her to try. A sympathetic invention would have been easy to accept that morning. She could feel the temptation and resented Lydia for leaving it visible.

"She put a name there," Ada said.

"Yes. That much we have."

Ada thought of the difference between having a place to grieve and having a body to bury. As a child she had not needed to hold that distinction in words. Now the records required it. They did not make her earlier visits meaningless. They made the purpose of the stone more deliberate than she had understood.

The phrase on it had sounded to her like an ending. The sea keeps its own. On the search paper there was no such finished sentence, only the limits of what people had been able to establish.

She closed her eyes, then opened them before Lydia could mistake it for permission to put the papers away.

"Keep going," Ada said.

The unknown surname remained. It no longer had to mean that her father's coffin had been exchanged or that the family had been cheated of a burial. Those were stories her alarm had offered before the records had supported them.

She was ashamed of how readily she had made the other occupant an intruder. Then she became angry again, this time at the years in which nobody had made the distinction plain to her. The archive did not tell her who knew what in every year. It left her to carry the anger without giving it an easy address.

## s3|A request in a woman's own words|After R09-R15

The letter sounded unlike the ledgers. Its writer wanted something and could say why. Ada had to remind herself that this, too, was a person's account, not an office speaking for everyone involved.

She set it beside the permission and reread the request about the name in the burial book. The wish to keep Roscoe's name on the stone had not been a wish to falsify the record below it. Yet the two ways of remembering had become so unequal that Ada had grown up seeing one and missing the other.

"It was loving," she said.

Then, before Lydia could agree, "It was unfair."

Lydia let both sentences remain.

Ada studied the marriages and household. She could follow a change of surname without assuming a change of person. She could test the relationships through more than one field. None of that told her whether the woman who made this request had imagined how completely her own name would disappear from Ada's knowledge.

Edith's permission was there too. Ada wanted to question her mother about it. She wanted the ordinary irritation of an answer she could argue with. Instead she had an instruction, a signature, and a neighboring plot.

At Holt & Son, the mason suggested enough space for a separate tablet. He waited this time, leaving the wording blank.

"I haven't finished the family line," Ada told him.

"Bring it when you have."

It was the first answer of his that did not push her toward completion. She thanked him, and meant it.

Back at the archive desk, she arranged the papers by the links she needed to prove. The right inscription depended on identifying the occupant, explaining the connection, and distinguishing the two plots. It did not require her to settle whether her mother had been wise, whether grief had made a fair request, or whether she ought to feel injured by a silence no longer available for explanation.

Lydia handed her another sheet. Ada wrote the family line carefully. Before giving anyone a permanent name in stone, she would give the records a full hearing.

## aftermath|Enough room for both|After the original solution and ending

Ada brought the proposed tablet back to Lydia before she took it to the mason. Miriam Cross. Born Dale. The woman the records connected to Roscoe as his mother and to Ada as her paternal grandmother.

"Will this do?" she asked.

Lydia checked the names and dates against the extracts. "The details agree. Whether it says what you want is yours to decide."

Ada had hoped, absurdly, that the records could finish that decision too.

At Harbor Rest, she stood between G17 and G18 with the paper in her hand. Miriam's burial in one. Edith's in the other. Roscoe remembered above a plot that had first been prepared as a memorial, without his remains. The arrangement was comprehensible at last. Being comprehensible did not make it painless.

She had begun the inquiry wanting to complete her mother's inscription. She had ended it responsible for a name her mother had permitted the book to preserve while the stone spoke of someone else. Ada could recognize the tenderness of that arrangement and refuse to repeat its imbalance.

At Holt & Son, she asked for the separate tablet. Roscoe's name would stay. Miriam's would be visible. Edith's place would be correctly identified.

The mason repeated the wording back to her, slowly. When he reached Miriam, Ada heard how unfamiliar the name still was in her own voice. A relationship could be proved in an afternoon of papers and still take time to become part of a life.

"I thought I knew what I was ordering," she said.

He set his pencil down. "Now you do."

She did not tell him that knowing the order was easier than knowing what to say to her mother. There was no one left to ask whether Edith had meant to protect her, assumed she knew, or simply allowed one unfinished conversation to become years. The surviving papers did not resolve that private history. Nor did they locate Roscoe's remains or establish an exact witnessed death.

Ada folded the approved wording around the copies of the records. She would keep both. One told her what to put on the stone. The other showed why the name belonged there.

The completed memorial would not make the sea return anyone. It would make one quieter correction on shore: a woman remembered for herself in the place where she had chosen to remain near the son she could not bring home.
