"""Package current editions; keep legacy inputs explicitly separate from releases."""
from pathlib import Path
import json, shutil, zipfile, hashlib, re
import fitz
from build_editions import CASES, ROOT, OUT, SRC, load_story

ORIGINAL=ROOT.parent/'mystery-originals'
PACK=ROOT/'packages';PACK.mkdir(exist_ok=True)
reports=json.loads((ROOT/'build-report.json').read_text())
bykey={r['case']:r for r in reports[:6]}
artifacts=[];bundles=[];ids={}

def artifact(p,audience='author'):
    p=Path(p).resolve()
    if str(p) in ids:return ids[str(p)]
    ident='f'+str(len(artifacts)+1);ids[str(p)]=ident
    kind='pdf' if p.suffix.lower()=='.pdf' else 'image' if p.suffix.lower() in ('.png','.jpg','.jpeg','.webp') else 'file'
    row={'id':ident,'path':str(p.relative_to(ROOT)),'audience':audience,'kind':kind}
    if kind=='pdf':row['pages']=len(fitz.open(p))
    if kind=='image':
        from PIL import Image
        with Image.open(p) as im:row['width'],row['height']=im.size
    artifacts.append(row);return ident

def zip_files(path,entries,audience):
    seen=set();members=[]
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,p,aud in entries:
            if name in seen:raise RuntimeError('Duplicate member '+name)
            seen.add(name);z.write(p,name);members.append({'artifact_id':artifact(p,aud),'name':name})
    with zipfile.ZipFile(path) as z:
        if z.testzip():raise RuntimeError('Corrupt ZIP '+str(path))
    bundles.append({'id':'z'+str(len(bundles)+1),'path':str(path.relative_to(ROOT)),'audience':audience,'members':members})

def local_tree(src,dst):
    dst.mkdir(parents=True,exist_ok=True)
    if not src.exists():return
    for p in src.rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:
            target=dst/p.relative_to(src);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)

def unzip(src,dst):
    dst.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(src) as z:
        for info in z.infolist():
            target=(dst/info.filename).resolve()
            if not target.is_relative_to(dst.resolve()):raise ValueError('Unsafe member')
            if not info.is_dir():
                target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(info))

char_notes={
'eleanor':{'Eleanor':'Wants to disclose the family records; protects originals and persists despite familial pressure. Missing during the inquiry, active through notebook and note.','Margaret':'Wants her daughter home and fears what the records say about Samuel. Moves from defensive care to permitting the inquiry to expose someone she loves.','Henry':'Loyal to both siblings. His act of uncovering Michael\'s letter resists the older brother\'s authority.','James':'Private debt and expected ownership motivate the established confinement. Pressure explains motive without excusing coercion.','Frank':'Has an established life beyond the excluded family. Supper is recognition, not automatic forgiveness.'},
'baby':{'Mabel':'Wants birth identity without denying the home the Suttons gave her. Rejects gratitude as a condition of being allowed to ask.','Edith':'Fears the search diminishes her motherhood. Begins as an obstacle, then helps while allowing a second family to matter.','Thomas':'Supports Mabel through concrete acts: a chair and room for papers. Cannot supply parentage he does not know.','Margaret':'The sealed letter gives her knowledge and shame a voice, while remaining unsent.','Patrick':'The carrier is confirmed only by the sealed letter. Family crisis can be understood without requiring forgiveness.'},
'inheritance':{'Nell':'Wants her claim heard without accepting a brother\'s promised provision as a substitute. Resists entitlement but does not prove a claim by being sympathetic.','Arthur':'Offers help while assuming his own precedence. His mistake is not made into established knowing fraud.','Clara':'Seeks equal scrutiny and recovers her own family identification even when it defeats her claim.','Ruth':'Insists on the will and full records; gives the rejected claimants procedural dignity.'},
'roscoe':{'Ada':'Wants to complete her mother\'s memorial; chooses to postpone the work so the unfamiliar occupant is not erased.','Lydia':'Frustrates Ada by declining to invent certainty, then earns trust through careful limits.','Mason':'Haste is an obstacle, not proof of malice; learns to wait for the investigated wording.','Miriam':'Her own letter protects her son\'s memorial while asking for an accurate burial entry. Ada can find the arrangement loving and unfair.','Edith':'Authorizes the established burial. Private reasons for later silence remain unproved.'},
'king':{'Daniel':'Bereaved and susceptible to the offer of renewed importance. Reads before signing; recognizes responsibility for believing the notice; gives Irene a choice about contact.','Orme':'Seeks a manageable claimant and definite result. K17 establishes present suppression, not a wider historical conspiracy.','Irene':'Has a profession, marriage, and independent life. Identity does not entitle Daniel to a welcome.','Margaret':'Deceased spouse and mother. Her illness is not used to invent guilt or a diagnosis.'},
'ashcombe':{'Celia':'Wants accurate treatment even if she loses. Refuses to turn Peter\'s embarrassment into an unsupported accusation.','Lawrence':'Presumes surname and gender settle entitlement and frames provision for Celia as his discretion.','Peter':'Corrects Lawrence\'s shortcut while relying on his own unfinished memorandum; intent remains unproved.','Ada':'Requires people to speak to her rather than over her; succession brings responsibilities rather than instant mastery.','Harcourt and Agnes':'Harcourt accepts correction in addressing Ada; Agnes respected her identity before it affected the estate.'}}

review={
 'method':'Two independent agents, each given only three player PDFs and ordinary instructions, with no hints, solutions, canon, or expected preferences.',
 'result':'All six reconstructed the established solutions with exhibit citations, tested competitors, and retained the intended uncertainties.',
 'narrative':'Each reviewer identified specific actions producing attachment, opposition, and shifts in sympathy. Daniel, Mabel, Eleanor and Frank, Ada Reeve, Nell, Celia and Ada Finch all received passage-specific responses.',
 'repairs':[{'case':'baby','issue':'Opening before wedding versus completed marriage extract in S1.','repair':'S1 now explicitly begins after the wedding.'},{'case':'roscoe','issue':'Wording implied an earlier inscription for Miriam.','repair':'Changed her own inscription to her own name.'}],
 'limits':'Agent simulation, not human enjoyment or timed human playtesting. Earlier Eleanor editions preserve their own evidence and receive the reviewed Eleanor narrative; they were not separately blind-tested.'
}
(ROOT/'blind-review.json').write_text(json.dumps(review,indent=2))

for c in CASES:
    key=c['key'];r=bykey[key];case_dir=PACK/c['slug'];case_dir.mkdir(exist_ok=True)
    customer=case_dir/'customer';customer.mkdir(exist_ok=True)
    entries=[]
    for kind in ['player','hints','solution','complete']:
        p=OUT/r['files'][kind];entries.append((p.name,p,'customer'))
    if key=='eleanor':
        for name in ['Eleanor-Hart-Illustrated-Book.pdf','Eleanor-Hart-200-Entry-Archive.pdf']:
            entries.append(('Alternate-editions/'+name,OUT/name,'customer'))
    start=customer/'START-HERE.txt'
    start.write_text(c['title']+'\nNarrative edition 2.0 / September 2026\n\nStart with '+r['files']['player']+'. It contains '+str(r['pages'])+' pages and includes the expanded story throughout the investigation.\n\nPrint the full Player PDF on US Letter at 100%, or A4 with Fit. Grayscale is sufficient. Use single-sided or long-edge duplex. Keep the Hints and Sealed Solution separate and closed until needed.\n\n'+r['files']['complete']+' contains all three sections and print ranges on its first page. Use either the separate files or the combined file, not both. Archive page references are stable printed folios; S0-S3 label the added story leaves. PDF positions differ. Bookmarks and catalog links navigate to the correct records.\n\nThe original clues, relationships, dates, case bounds, and answers are preserved. New scenes develop the characters; the solution includes an expanded aftermath.\n'+ ('\nAlternate-editions contains the same Eleanor case in illustrated-book and 200-entry paper-archive formats. These are alternatives, not two additional mysteries. Each retains its own questions and records.\n' if key=='eleanor' else ''))
    entries.append(('START-HERE.txt',start,'customer'))
    zip_files(OUT/(c['slug']+'-Customer.zip'),entries,'customer')
    # Maintain source, original evidence, and story events for future revisions.
    author=case_dir/'author';author.mkdir(exist_ok=True)
    notes={'case':c['title'],'edition':'2.0','creative_brief':'48 Hours + Ancestry.com + Lindsay Clancy trial, used as investigative intimacy, archive discovery, divided sympathy and responsibility; no copied real-case facts.','character_notes':char_notes[key],
      'canon_policy':'Original people, kinship, dates, evidence claims, rules and solutions remain authoritative. The linked narrative text adds fictional encounters, dialogue and post-resolution choices. It supplies no required clue. Uncertainty remains uncertainty.',
      'story_events':[{'id':k,**v,'canon_role':'expanded fictional scene; non-clue' if k!='aftermath' else 'post-commitment fictional aftermath'} for k,v in load_story(key).items()],
      'source_priority':['Original case data and locked handoff','Original numbered evidence and evidence-cited answer','Narrative scenes for character and aftermath only'],
      'provenance_note':'The Inheritance original author ZIP was corrupt. Its intact customer PDFs and marketing assets are maintained as inputs; the new renderer and narrative sources rebuild this edition.' if key=='inheritance' else ''}
    (author/'narrative-canon.json').write_text(json.dumps(notes,indent=2,ensure_ascii=False))
    (author/'build-report.json').write_text(json.dumps(r,indent=2))
    (author/'README.md').write_text('# '+c['title']+' - narrative edition 2.0\n\nBuild with `python3 source/build_editions.py --case '+key+'`. Requirements: reportlab, pymupdf, pypdf, Pillow. DejaVu fonts are included.\n\n`originals/` contains immutable prior-edition PDF inputs, not customer releases. Their archive folios are retained. `source/stories/` and `narrative-canon.json` contain the actual new writing and its role in canon. Output PDFs are written to `output/`. `legacy-source/` preserves recovered earlier author data; use the new builder for this edition.\n\nCritical evidence regions are required to render identically to the original inputs. The builder rewrites instructions, remaps catalog links, preserves folios, interleaves scenes and appends aftermaths. `blind-review.json` records the independent player-only simulation and its limits.\n\nOriginal and earlier edition files in this author package are source material only. Supply the separate Customer ZIP to readers.\n')
    ae=[('README.md',author/'README.md','author'),('narrative-canon.json',author/'narrative-canon.json','author'),('build-report.json',author/'build-report.json','author'),('blind-review.json',ROOT/'blind-review.json','author')]
    for p in [Path(__file__).parent/'build_editions.py',Path(__file__).parent/'verify_render.py']:
        ae.append(('source/'+p.name,p,'author'))
    ae.append(('source/stories/'+key+'.md',Path(__file__).parent/'stories'/f'{key}.md','author'))
    for p in (Path(__file__).parent/'fonts').glob('*'):ae.append(('source/fonts/'+p.name,p,'author'))
    for name in [c['player'],c['hints'],c['solution']]+(['eleanor-book.pdf','eleanor-archive.pdf'] if key=='eleanor' else []):ae.append(('originals/'+name,SRC/name,'author'))
    legacy_map={'eleanor':'eleanor-hart-print-bundle/publisher-source','baby':'baby-in-a-basket-author-source','inheritance':'The-Inheritance-Author/author','king':'If-I-Were-King-Author/author','roscoe':'Roscoes-Grave-Author/author','ashcombe':'The-Last-Ashcombe-Author/author'}
    lr=ORIGINAL/'extracted'/legacy_map[key]
    legacy=author/'legacy-source';local_tree(lr,legacy)
    for p in legacy.rglob('*'):
        if p.is_file() and p.suffix.lower()!='.pdf':ae.append(('legacy-source/'+str(p.relative_to(legacy)),p,'author'))
    ae += [('customer/'+name,p,aud) for name,p,aud in entries]
    zip_files(OUT/(c['slug']+'-Author.zip'),ae,'author')

    # Existing marketing PDFs need to match the current product. Reuse owned art.
    if key in ('inheritance','king','roscoe','ashcombe'):
        marketing=case_dir/'marketing'
        original_zip=ORIGINAL/(c['slug']+'-Marketing.zip')
        try:unzip(original_zip,marketing)
        except zipfile.BadZipFile:
            local_tree(ORIGINAL/'extracted'/(c['slug']+'-Author')/'marketing',marketing)
        for p in list(marketing.rglob('*.pdf')):
            if 'preview' in p.name.lower():shutil.copy2(OUT/r['files']['preview'],p)
            elif 'cover' in p.name.lower():
                d=fitz.open(OUT/r['files']['player']);v=fitz.open();v.insert_pdf(d,from_page=0,to_page=0,links=False);v.save(p)
        for p in list(marketing.rglob('*.md'))+list(marketing.rglob('*.txt')):
            txt=p.read_text()
            txt=re.sub(r'(?i)edition 1\.0','Narrative edition 2.0',txt)
            # Replace page-count advertising rather than accidentally editing dates.
            old=len(fitz.open(SRC/c['player']))
            txt=re.sub(r'\b'+str(old)+r'(?=\s*[- ]page)',str(r['pages']),txt,flags=re.I)
            txt=re.sub(r'\b'+str(old)+r'(?=\s+pages)',str(r['pages']),txt,flags=re.I)
            txt='Current PDF edition: 2.0. Player file: '+str(r['pages'])+' pages; hints: '+str(len(fitz.open(OUT/r['files']['hints'])))+'; sealed solution: '+str(len(fitz.open(OUT/r['files']['solution'])))+'. Expanded scenes and aftermath included.\n\n'+txt
            p.write_text(txt)
        shutil.copy2(OUT/r['files']['preview'],marketing/(c['slug']+'-Preview.pdf'))
        me=[(str(p.relative_to(marketing)),p,'marketing') for p in sorted(marketing.rglob('*')) if p.is_file()]
        zip_files(OUT/(c['slug']+'-Marketing.zip'),me,'marketing')

# Refresh the historical Ashcombe complete archive and Eleanor revision package.
ash=PACK/'The-Last-Ashcombe';entries=[]
for p in (ash/'marketing').rglob('*'):
    if p.is_file():entries.append(('marketing/'+str(p.relative_to(ash/'marketing')),p,'marketing'))
for p in OUT.glob('The-Last-Ashcombe-*.pdf'):
    entries.append(('marketing/'+p.name if 'Preview' in p.name else 'customer/'+p.name,p,'marketing' if 'Preview' in p.name else 'customer'))
# Avoid duplicate preview path.
entries=list({n:(n,p,a) for n,p,a in entries}.values())
for n in ['The-Last-Ashcombe-Author.zip']:
    # Nested source archive is an artifact distinct from the standalone bundle entry.
    target=PACK/'archive-inputs'/n;target.parent.mkdir(exist_ok=True);shutil.copy2(OUT/n,target)
    entries.append(('author/'+n,target,'author'))
entries.append(('customer/START-HERE.txt',ash/'customer'/'START-HERE.txt','customer'))
zip_files(OUT/'The-Last-Ashcombe-Complete.zip',entries,'author')

rev=PACK/'Eleanor-Legacy-Package';unzip(ORIGINAL/'eleanor-hart-revision-package.zip',rev)
for p in rev.rglob('*.pdf'):shutil.copy2(OUT/'Eleanor-Hart-Illustrated-Book.pdf',p)
(rev/'READ-ME-FIRST.txt').write_text('The PDF in output/book is the expanded narrative edition 2.0. Earlier manuscript/DOCX and scripts are retained as historical sources. Use the current Eleanor-Hart-Author.zip for the maintained narrative sources and reproducible PDF builder. The previous manuscript alone will not rebuild this new edition.\n')
zip_files(OUT/'Eleanor-Hart-Revision-Package.zip',[(str(p.relative_to(rev)),p,'author') for p in sorted(rev.rglob('*')) if p.is_file()],'author')

# One customer download, containing the full standalone PDFs rather than nested ZIPs.
collection=[]
for c in CASES:
    for k in ['player','hints','solution','complete']:
        p=OUT/bykey[c['key']]['files'][k];collection.append((c['slug']+'/'+p.name,p,'customer'))
    p=PACK/c['slug']/'customer'/'START-HERE.txt';collection.append((c['slug']+'/START-HERE.txt',p,'customer'))
for n in ['Eleanor-Hart-Illustrated-Book.pdf','Eleanor-Hart-200-Entry-Archive.pdf']:
    collection.append(('Eleanor-Hart/Alternate-editions/'+n,OUT/n,'customer'))
readme=PACK/'START-HERE.txt';readme.write_text('MYSTERY SERIES / NARRATIVE EDITION 2.0\n\nSix cases: Eleanor Hart Is Missing; Baby in a Basket; The Inheritance; Roscoe\'s Grave; If I Were King; The Last Ashcombe.\n\nEach folder has a Player PDF, optional Hints, a Sealed Solution with expanded aftermath, and a Complete PDF. Start with the Player file. Keep hints and solutions separate. Eleanor also includes two alternative editions of the same case.\n\nThe new narrative follows characters through the archive and gives the reader reasons to care about, resist, and reconsider them. Original evidence and case answers are preserved. Read the setup in each file for stable archive folios and physical print positions.\n\nThe Wrong Widow is not included: no case PDF or authoritative game source was available to revise. Its landing page is not sufficient to reconstruct the mystery.\n')
collection.append(('START-HERE.txt',readme,'customer'))
zip_files(OUT/'Mystery-Series-Narrative-Edition.zip',collection,'customer')

# Shared portable source handoff. No storefront publication is implied.
handoff=[]
for folder in ['source','originals']:
    for p in (ROOT/folder).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:handoff.append((str(p.relative_to(ROOT)),p,'author'))
for c in CASES:
    p=PACK/c['slug']/'author'/'narrative-canon.json';handoff.append(('case-notes/'+c['key']+'.json',p,'author'))
for n in ['build-report.json','blind-review.json','structural-review.json','visual-review-manifest.json']:
    handoff.append((n,ROOT/n,'author'))
guide=PACK/'AUTHOR-README.md';guide.write_text('# Mystery series narrative edition 2.0\n\nRun `python3 source/build_editions.py` to build all six current cases and both alternate Eleanor editions. Run `python3 source/verify_render.py` to render all pages and validate links and text bounds. Requirements: reportlab, pymupdf, pypdf, Pillow.\n\nThe original PDFs are immutable build inputs, not revised customer releases. Actual story prose is under source/stories. Each case note registers character choices, narrative canon, source priority, and uncertainties. Original evidence above the footer is checked for exact pixel equality during every build.\n\nTwo independent player-only agent reviews solved all six cases and supplied passage-specific emotional feedback. This was not a human playtest. The two alternate Eleanor editions preserve their own evidence and questions.\n\nThe Wrong Widow remains blocked by missing game materials. No Gumroad listing or customer delivery attachment was changed by this PDF revision.\n')
handoff.append(('README.md',guide,'author'))
zip_files(OUT/'Mystery-Series-Author-Handoff.zip',handoff,'author')

for p in OUT.glob('*.pdf'):artifact(p,'marketing' if 'Preview' in p.name else 'customer')
(ROOT/'release-manifest.json').write_text(json.dumps({'case':'Mystery Series','edition':'2.0','artifacts':artifacts,'bundles':bundles},indent=2))
print('Packaged',len(bundles),'ZIPs;',len(artifacts),'manifest artifacts')
