# Mystery series narrative edition 2.0

Run `python3 source/build_editions.py` to build all six current cases and both alternate Eleanor editions. Run `python3 source/verify_render.py` to render all pages and validate links and text bounds. Requirements: reportlab, pymupdf, pypdf, Pillow.

The original PDFs are immutable build inputs, not revised customer releases. Actual story prose is under source/stories. Each case note registers character choices, narrative canon, source priority, and uncertainties. Original evidence above the footer is checked for exact pixel equality during every build.

Two independent player-only agent reviews solved all six cases and supplied passage-specific emotional feedback. This was not a human playtest. The two alternate Eleanor editions preserve their own evidence and questions.

The Wrong Widow is maintained separately in this repository. See ASSET_INDEX.md at the repository root for current availability and release status.

Authorship and release authority: Owner_Bot. Grok implements approved Shopify storefront and product updates only; coordination is through GitHub. The originals/ directory contains required immutable evidence inputs for the current builder, not alternate customer releases.
