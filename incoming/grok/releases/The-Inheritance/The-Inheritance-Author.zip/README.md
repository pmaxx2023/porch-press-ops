# The Inheritance - narrative edition 2.0

Build with `python3 source/build_editions.py --case inheritance`. Requirements: reportlab, pymupdf, pypdf, Pillow. DejaVu fonts are included.

`originals/` contains immutable prior-edition PDF inputs, not customer releases. Their archive folios are retained. `source/stories/` and `narrative-canon.json` contain the actual new writing and its role in canon. Output PDFs are written to `output/`. `legacy-source/` preserves recovered earlier author data; use the new builder for this edition.

Critical evidence regions are required to render identically to the original inputs. The builder rewrites instructions, remaps catalog links, preserves folios, interleaves scenes and appends aftermaths. `blind-review.json` records the independent player-only simulation and its limits.

Original and earlier edition files in this author package are source material only. Supply the separate Customer ZIP to readers.
