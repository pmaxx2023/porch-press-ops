# Baby in a Basket

## opening|The question before the wedding|Before the opening brief / Mabel's family story

Edith had always been able to tell the story of the basket. The church, the little girl, the home waiting for her. When Mabel was small, the telling ended with Edith drawing her close. It was a good ending for a child who wanted to be certain she belonged.

As a grown woman preparing to enter her name in another register, Mabel discovered that the same ending could close a door.

"What am I to put?" she asked.

Edith looked at the paper. "Sutton. You've always been Sutton."

"I know my name. I mean before."

Thomas kept his eyes on the table. He could repair a thing with a split in it. He could not make this question fit neatly beside the life they had given her.

Edith reached to straighten Mabel's sleeve. Mabel let her. She loved that hand. She also wanted it to stop answering questions nobody had asked.

"We don't have those names," Edith said.

"Then I want to look."

For a moment Edith's face made Mabel feel as though she had announced she was leaving them. The unfairness of that feeling brought heat to her eyes. She had not wanted an argument. She had wanted permission not to know something and still need to know it.

"Was there something you lacked here?" Edith asked.

Thomas moved then, drawing a chair out so Mabel could sit. "She asked about the papers."

Edith looked at him, hurt. He did not withdraw the chair.

Mabel sat. "I can be grateful and ask. Can't I?"

The answer took long enough to matter.

Edith put her hand flat on the table. "Yes."

They had no account of the person who carried the basket. The old newspaper did not provide one. Thomas and Edith could tell Mabel how she had come into their care, but their love did not turn that knowledge into a birth record.

Mabel drew the clipping toward her. For the first time she read the estimate of the infant's age as something a doctor had tried to judge, not as the beginning of a story she had to accept whole.

She wanted a name. She was afraid of the reason it had been taken away. Across the table, Edith was afraid that finding it would make Sutton seem smaller. Neither fear could choose the answer. Somewhere in the county's ordinary papers, other children had been entered under other parents' names.

## s1|What a zero can wound|After BB01-BB03

After the wedding, Mabel brought the marriage extract back to the table with the older papers. Edith's eyes stopped at the census fields. Children born: zero. Children living: zero.

"That isn't what my life was," she said.

Mabel understood the protest before she understood the column. She could supply ten years of contradiction: being dressed, fed, scolded, waited for. She wanted to cross out the zero as fiercely as Edith did.

Then she read the heading again. The count belonged to a particular question. The form had not attempted to measure every kind of motherhood.

"It doesn't say you didn't raise me."

"It looks as if I had no one."

Mabel turned the schedule so they could both see her own line. Daughter. There she was, inside the household and beside the entry that made her ask how she had entered it.

Thomas stood behind Edith's chair. He did not correct either of them. Mabel thought of all the times he had made room for her without making a speech about it. She wanted the investigation to leave that part of their life intact. Wanting was not a method of reading a record.

The marriage extract gave the parents who had raised her. It also left biological parentage unknown. Neither paper erased the other; each had asked for something different.

Edith touched the clipping. "They said she was in good health. I remember being glad of that."

Mabel noticed the change of pronoun. She, the infant. A small person who had existed before Edith could say my daughter. It made the distance visible without explaining it.

"I don't want to lose this family," Mabel said. "I'm trying to find what happened to the other one."

Edith took her hand away from the paper. There was no grand promise in the gesture. She simply stopped holding down the page Mabel wanted to turn.

The entries would need comparison. A census could be mistaken; an adult name could preserve a childhood story without identifying its beginning. The papers offered routes into the question, not a reason to stop loving anyone already in the room.

## s2|Four small lives|After BB04-BB09

Mabel copied the four girls' names onto separate lines. At first the task felt almost shameful, as though she were trying on other people's childhoods to see which would fit.

Ruth. Nora. Elsie. Mabel.

Thomas watched her compare the households. "Does one look right?"

"Looking right isn't enough."

She had wanted to answer differently. A familiar given name could feel like recognition before it proved anything. A mother's death could make a terrible story seem complete before she had followed the child beyond it.

Edith read the death entries. "There were three of them."

Three women reduced here to the selected fields of a county register. The extracts did not give a cause. They did not say who put the next meal on the table, who took over the smallest child's washing, or whether the husband accepted help. Those missing scenes pressed into Mabel's mind because she was looking for her own. She had to resist writing them into the evidence.

"A man loses his wife," Thomas began, then stopped.

"And a child loses her mother," Mabel said.

He nodded. "Yes."

Neither sentence settled what happened afterward. Even grief did not make every household do the same thing. The archive held later records. Those children had lives beyond the moment at which this investigation first needed them.

Mabel put the full birth entries beside the index instead of discarding the names that seemed less likely. She wrote event dates separately from dates on newspaper headings. It was slow work, and for once slowness felt like respect.

Edith brought another chair close enough to read over her shoulder. She asked which paper Mabel wanted next. The question was so ordinary that Mabel nearly missed what had changed: her mother was no longer asking why she wanted another paper at all.

They would follow each child as far as the supplied records allowed. Nobody would be chosen merely because her losses made the most affecting explanation.

## s3|A household is not a whole life|After BB10-BB20

The later households would not fit on the same sheet as the earlier ones. Mabel took another page. Thomas offered a larger piece of paper, then waited to see whether she wanted it before clearing the table.

Boarder. Niece. Daughter. Granddaughter.

Each word put someone in relation to the person named at the head of the household. None said whether she liked the room, whether he wrote home, or what it felt like to leave. Mabel could trace the recorded connections without pretending she had recovered all those answers.

"They might have been well cared for," Edith said.

Mabel looked up sharply. "They might have missed someone anyway."

Edith drew a breath. "I know."

Mabel had expected an argument. The absence of one made her hear how much Edith was allowing the sentence to include.

Thomas rested his hands on the back of his chair. He wanted the papers to deliver a person he could blame or thank. Mabel could see the impatience in him because she felt it herself. Somebody had carried a basket. Somebody had walked away. It was easier to picture a face than to accept that the public account did not supply one.

The church care entry was plain about the next day. Thomas and Edith had received the infant into their home. The entry did not turn backward and identify the person from the morning before.

Mabel read it aloud. Her voice was steady until she reached their names.

"We wanted you," Edith said.

"I believe you."

She did not add that this answered everything. Edith did not ask her to.

Mabel made two headings on the work sheet: what the records establish, and what they leave open. Beneath the second she left room. Uncertainty was not the same as having no family. It was a part of this family story that nobody at the table had earned the right to fill by guesswork.

The names still had to be connected, the alternatives tested, the dates counted. After that, there would remain another question: whether understanding a separation would make it feel any less like being left.

## aftermath|The letter stayed in the drawer|After the sealed letter and answer key

Margaret wrote her sister's name and held the pen above the next line. In 1942, there were words for the family relationship that had been missing from Mabel's own account. There was no sentence that could give the years back.

She wrote Patrick. Nora. The birthday. The ten children. The names were plain enough when set down separately. What had been difficult was making them live in the same letter as what Father had done.

At eleven, she had not been the adult responsible for keeping the household together. Remembering that did not stop her from revisiting the house as if there were an overlooked task she might still complete. Carry something. Fetch someone. Speak before the basket was gone. The mind could keep giving a child duties the child had never possessed the power to carry out.

She did not write a scene she had not witnessed. She wrote the account preserved in the letter: Father had left Mabel at Grace Church. The public records could support the family crisis; this private paper finally named the person who carried out that act.

To explain it was to risk sounding as if she excused it. To give no explanation was to make the family seem incapable of love. She wanted a third way and could not find a sentence that guaranteed how her sister would hear it.

She left the admission about keeping the letter. Perhaps that was another failure. It was the least comfortable line and the one she did not cross out.

When the page was finished, she laid the pen down. The letter remained unsent. What Mabel would have made of it was a question the page could not answer.

What you have recovered is therefore uneven. The identity is strong within the closed case: Mabel Reilly, daughter of Patrick and Nora, later Mabel Ruth Sutton. The private letter confirms Patrick's act. Some siblings can be traced in the supplied households; others remain untraced. The record of a mother raising no biological children does not diminish the home Edith made. The record of a father in crisis does not make the child's loss disappear.

Margaret could put a name on what happened. She could not control what that name would mean to Mabel. The final unfinished business was no longer a missing field in a register. It was the distance between telling a truth somewhere on paper and telling it to the person who had spent a life without it.
