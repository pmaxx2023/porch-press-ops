# Eleanor Hart Is Missing

## opening|The supper kept warm|Before the opening brief

Margaret had left the warming oven open. By morning there was nothing in it worth saving, but shutting the door seemed too much like agreeing that the meal was over.

Henry stood beside the table with his cap crushed between his hands. He was old enough to work at the works and young enough to look at his mother whenever something had to be decided. She wanted him to say something useful. Instead he asked whether she had slept.

"Have you?" she said.

He shook his head. She put a cup in front of him. It was easier to be angry while doing something kind.

The telegram lay beside Eleanor's place. Margaret had read it until the capital letters ceased to resemble her daughter's voice. Gone away. Do not look. She could imagine Eleanor going somewhere without permission. That was different from believing she had sent this message. Her daughter was twenty-five; Margaret knew she could not make a disappearance impossible merely by calling it unlike her.

"James says she went," Henry said.

"I know what James says."

He looked down. She heard what she had done: made him choose between an absent sister and the brother he would have to face at work. She touched his sleeve.

"Tell them what you know. Not what will make me feel better."

When George arrived, his expression was the careful one he used for estate business. He put his papers on the table, then moved them away from Eleanor's plate. Margaret watched that small correction. For sixteen months, since Samuel's death, George had been the person who knew what had to be signed and what could wait. This morning she needed him to admit that he might not know.

"She asked you to listen," she said.

"I intended to."

"Then start with what she left here."

George reached for the portfolio of copies. Margaret did not let go at once. Some part of her still wished Eleanor had left the old registers alone. She hated herself for the wish, and hated that it had survived the night.

Henry drew his chair closer. Nobody ate. The papers were spread between people who loved the same missing woman and no longer knew whether they could trust the same brother.

## s1|The first wife's name|After EH03-EH04 / Documents 03-04

Margaret read the marriage entry without moving her lips. Samuel's name was familiar enough to make the rest of the line seem a mistake.

Ellen Byrne.

There were dates she could test, a parish to ask, a child to trace. Those were the useful things. The useless thing was the sudden desire to remember every occasion on which Samuel might have told her and had not.

George waited. That irritated her more than a question would have done.

"You needn't watch me," she said. "I can read it."

"I wasn't certain you would want to."

She looked at him then. Eleanor's notebook would preserve her own awkward response to the discovery: asking whether her daughter had eaten. Margaret had meant to keep one ordinary thing from falling apart. She could see how it might have sounded like asking Eleanor to stop.

"Would wanting change the entry?"

George turned the page so the burial extract lay beside the marriage. The formal lines offered no account of what kind of wife Ellen had been. They did not say whether she laughed loudly, whether she worried over money, whether someone had sat beside her at the end. Margaret had first experienced her as an intrusion. Here was the record of her death.

She was ashamed of the order in which her feelings had arrived.

"I don't want my children made smaller by this," she said.

George did not answer quickly. "We have to find out what this is before we decide what it takes from anyone."

Margaret smoothed the edge of the copy. It had not been torn. She was smoothing something that did not need mending.

Eleanor had met the same names in the same narrow columns and kept going. For the first time that morning, her mother understood the work as more than a daughter upsetting a house. Someone had once occupied these lines. Somebody had been left to carry the memory of her.

That still did not tell Margaret whom to trust. It gave her a reason to turn the next page.

## s2|What the payments could not buy|After EH07-EH08 / Documents 07-08

Henry stopped at the seed cake. Of all the things in Michael Byrne's letter, that was the detail he read twice.

"Twenty-eight," he said. "And she still made it."

Margaret knew what he was trying to imagine. A birthday in a house none of them had visited. A man who could be passed in the street and asked about his work. A father's money arriving on time while the invitation never arrived at all.

"We weren't told," Henry said.

"No."

He seemed to need more than that. She could not give him innocence on behalf of every adult in the family. She could only leave room for the question.

George laid his executor's memorandum beside the letter. Its orderly sentences looked different now. He had written down what Samuel told him; he had prepared to act upon it. Whatever the investigation ultimately established, repeating a trusted man's account had not made the account independent evidence.

"James has been doing the work," Henry said. He sounded almost apologetic. "That part is true."

"It may be," George said. "The gift has words of its own."

Margaret disliked the coldness of that answer until she considered its alternative: each of them editing the will to reward the person already nearest to them. James's work did not vanish because another record existed. Neither could another person be made to vanish because James's work mattered.

Michael's letter did not ask the younger children to apologize for being born. It asked Samuel to do something plain. Tell him yourself. Margaret found the simplicity of it unbearable.

Henry moved the letter out from under the estate paper.

"Don't cover it," he said.

She left it where he put it. They still needed the records that connected one name to another, and evidence that reached the present day. Affection was not a certificate. But the certificates were no longer an exercise in tidying a pedigree. Whatever name the investigation established, there was a person at the other end who had once waited to be asked inside.

## s3|A reason is not a permission|After EH09-EH10 / Documents 09-10

The amount in the lender's letter drew Henry's eye before anything else. He had never held twelve hundred dollars. Written beside the due date, it made James's confidence about Wednesday look less like confidence.

"He must have thought he could put it right," Henry said.

Margaret heard an old family habit in the sentence: take the frightening thing, find a gentler name for it, and hope the new name will hold.

"We don't know what he did," she answered.

Henry looked relieved. She made herself finish.

"That means we must find out. It doesn't mean we may stop."

George read Eleanor's notebook again. She had intended to bring copies, protect the original letter, go home for supper, and put the matter before him. Even in private she was thinking about what papers would survive being carried through the works. Her care was practical. She had not known she would need someone else to follow it.

Margaret paused at the words about James thinking it unkind. She knew how effective that accusation could be inside a family. Cruelty sounded like shouting. Unkindness could be laid at the feet of the quiet person asking a question.

"I wanted her to leave it for a day," she said. "I wanted one supper without these names in it."

Neither man offered to absolve her. For once she was grateful. There was a difference between wishing a daughter would stop asking and making her unable to speak. There was also work to do before anyone could say what had happened at the works.

George drew the attendance reply and office records toward him. They had been made for different purposes by people with different things to notice. A debt could explain pressure. A frightened family could supply a theory. Neither could place a man at a particular door.

Henry opened his hands and let the cap rest on the table. "Then we follow it all the way," he said.

Margaret nodded. She wanted Eleanor home. She was beginning to understand that she could not make that wish conditional on what bringing her home might reveal.

## aftermath|The chair was only a beginning|After the original solution and ending

At supper, Frank did not take Samuel's chair. Nobody had asked him to, but Margaret noticed the care with which he chose another.

She had imagined this meeting as an arrival: open the door, set another place, and the exclusion would at last be over. Instead she found herself wondering whether to pass him the bread before Henry, whether using Francis would sound intimate or merely ignorant, whether an apology would ask a guest to comfort his hosts.

Eleanor had been rescued. That fact deserved all the relief the house could hold. It did not make the other facts easier. James was still her son. Frank was still a stranger to her. Samuel, who had arranged so much of their ignorance, could answer none of their questions.

"Michael calls me Frank," their guest said when George hesitated over his name.

Margaret was grateful for the instruction. "Frank, then."

Henry asked about the practical examination. It was a real question, about work he wanted to understand, and Frank answered it. For a few minutes nobody needed to discuss the estate. Eleanor listened with her hands below the edge of the table. When a door sounded in the passage, she looked up too quickly. Her mother saw it and kept her own hands still.

Later, George spoke of checking the originals. He said plainly that the works had not been delivered to James. He did not ask Frank to admire his caution now, after the years in which he had believed Samuel's account.

"I should have checked what I was told," he said.

Frank regarded him for a moment. "You can check it now."

It was less than forgiveness and more useful than reassurance.

When Margaret began, "If we had known," Eleanor touched the folded napkin beside her plate. Her mother stopped. She had almost offered an impossible history in place of the evening they actually had.

"I don't know what you would like us to call this," Margaret said instead.

"Supper," Frank answered. There was a small kindness in it, and a boundary.

After he had gone, Eleanor refused to have her portfolio put away in Samuel's desk. She asked for it in her own room. Margaret carried it upstairs and left it where her daughter could reach it.

The investigation had established the relationship, the confinement, the false message, and the place to search. It had not established that a new brother could replace an old one, or that a meal could repay thirty-four years. George still had papers to examine. The family had something smaller for this evening: the right names spoken aloud, and an invitation that had finally been made.
