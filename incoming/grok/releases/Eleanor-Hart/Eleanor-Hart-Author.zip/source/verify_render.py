from pathlib import Path
import fitz, hashlib, json
from PIL import Image, ImageDraw

root=Path(__file__).resolve().parent.parent
dst=root/'work'/'visual';dst.mkdir(parents=True,exist_ok=True)
seen={};items=[];manifest=[];issues=[]
for p in sorted((root/'output').glob('*.pdf')):
    d=fitz.open(p)
    for i,page in enumerate(d):
        for l in page.get_links():
            if l['kind']==fitz.LINK_GOTO and not (0<=l['page']<len(d)):
                issues.append({'file':p.name,'page':i+1,'issue':'broken link'})
        pix=page.get_pixmap(matrix=fitz.Matrix(1,1),alpha=False)
        h=hashlib.sha256(pix.samples).hexdigest()
        if h not in seen:
            uid=len(items)+1;seen[h]=uid
            img=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);img.save(dst/f'{uid:04}.png')
            items.append((uid,p.name,i+1,page.get_label()))
        manifest.append({'file':p.name,'page':i+1,'label':page.get_label(),'visual':seen[h],'sha256':h})
        # Catch glyph and clipping defects in the freshly authored story pages.
        if page.get_label().startswith(('S0-','S1-','S2-','S3-','A-')):
            for block in page.get_text('dict')['blocks']:
                for line in block.get('lines',[]):
                    for span in line['spans']:
                        x0,y0,x1,y1=span['bbox']
                        if x0<40 or x1>570 or y0<20 or y1>774 or '\ufffd' in span['text']:
                            issues.append({'file':p.name,'page':i+1,'issue':'text bounds or glyph','text':span['text']})
for k in range(0,len(items),20):
    sheet=Image.new('RGB',(1220,1400),'#e6e8e6');draw=ImageDraw.Draw(sheet)
    for j,(uid,name,pg,label) in enumerate(items[k:k+20]):
        x=(j%5)*244+6;y=(j//5)*350+5
        im=Image.open(dst/f'{uid:04}.png');im.thumbnail((230,308));sheet.paste(im,(x,y))
        draw.text((x,y+310),f'{uid:04} {name[:25]}',fill='black')
        draw.text((x,y+324),f'PDF {pg} | {label}',fill='black')
    sheet.save(dst/f'contact-{k//20+1:02}.jpg',quality=88)
(root/'visual-review-manifest.json').write_text(json.dumps(manifest,indent=2))
(root/'structural-review.json').write_text(json.dumps({'pages_rendered':len(manifest),'unique_page_images':len(items),'issues':issues},indent=2))
print('Rendered',len(manifest),'pages;',len(items),'unique images;', (len(items)+19)//20,'sheets; issues:',len(issues))
if issues:raise SystemExit(1)
