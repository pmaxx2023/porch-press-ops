#!/usr/bin/env python3
"""Build reproducible narrative editions while preserving the original evidence pages.

Run from this directory with Python containing reportlab, pymupdf, and pypdf.
Original PDFs are immutable build inputs in ../originals. Narrative text is in stories.
Archive folios remain stable; new story leaves use S labels. Links are remapped.
"""
from pathlib import Path
from io import BytesIO
from html import escape
import json, re, hashlib, math
import fitz
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'originals'
OUT = ROOT / 'output'
TMP = ROOT / 'work'
for p in [SRC, OUT, TMP]: p.mkdir(parents=True, exist_ok=True)
FD = Path(__file__).parent / 'fonts'
if not FD.exists(): FD = Path('/usr/share/fonts/truetype/dejavu')
for name, file in [('Book','DejaVuSerif.ttf'),('BookBold','DejaVuSerif-Bold.ttf'),('Sans','DejaVuSans.ttf'),('SansBold','DejaVuSans-Bold.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FD/file)))
pdfmetrics.registerFontFamily('Book', normal='Book', bold='BookBold', italic='Book', boldItalic='BookBold')
pdfmetrics.registerFontFamily('Sans', normal='Sans', bold='SansBold', italic='Sans', boldItalic='SansBold')
INK=HexColor('#252b2b'); MUTED=HexColor('#515b5a'); ACCENT=HexColor('#59685d')
STYLE=ParagraphStyle('body',fontName='Book',fontSize=11.15,leading=16.2,textColor=INK,spaceAfter=8.5,allowWidows=0,allowOrphans=0)
SMALL=ParagraphStyle('small',fontName='Sans',fontSize=9.0,leading=12.5,textColor=MUTED,spaceAfter=11)
HEAD=ParagraphStyle('head',fontName='Book',fontSize=25,leading=30,textColor=INK,spaceAfter=16)
SUB=ParagraphStyle('sub',fontName='SansBold',fontSize=9.2,leading=13,textColor=ACCENT,spaceAfter=11)
LOG=[]

CASES=[
 dict(key='eleanor',title='Eleanor Hart Is Missing',slug='Eleanor-Hart',player='eleanor-player.pdf',hints='eleanor-hints.pdf',solution='eleanor-solution.pdf',instructions=2,opening=2,story_after=[8,12,14],evidence=list(range(5,21)),start='EH01-EH03',catalog='archive folio 4',work='archive folios 21-26',h_offset=26,s_offset=30,solution_cover=True,first_evidence=5,extra='The original investigation has sixteen exhibits and six final deductions.'),
 dict(key='baby',title='Baby in a Basket',slug='Baby-in-a-Basket',player='baby-player.pdf',hints='baby-hints.pdf',solution='baby-solution.pdf',instructions=2,opening=2,story_after=[7,15,26],evidence=list(range(5,8))+list(range(10,27)),start='BB01-BB03',catalog='archive folios 8-9',work='archive folios 27-32',h_offset=32,s_offset=36,solution_cover=True,first_evidence=5,extra='The four birth identities are the complete candidate set. The sealed letter supplies private confirmation only after you commit.'),
 dict(key='inheritance',title='The Inheritance',slug='The-Inheritance',player='inheritance-player.pdf',hints='inheritance-hints.pdf',solution='inheritance-solution.pdf',instructions=4,opening=1,story_after=[8,12,18],evidence=list(range(5,19)),start='E01-E02',catalog='archive folio 3',work='archive folios 19-21',h_offset=0,s_offset=0,solution_cover=True,first_evidence=5,extra='C1-C3 are the complete possible living beneficiaries in this fictional case. Apply the bequest printed in E01.'),
 dict(key='roscoe',title="Roscoe's Grave",slug='Roscoes-Grave',player='roscoe-player.pdf',hints='roscoe-hints.pdf',solution='roscoe-solution.pdf',instructions=4,opening=1,story_after=[10,12,19],evidence=list(range(5,20)),start='R01-R02',catalog='archive folio 3',work='archive folios 20-22',h_offset=0,s_offset=0,solution_cover=True,first_evidence=5,extra='This case concerns bereavement and loss at sea, without graphic violence. A headstone, a memorial, and a recorded burial are different kinds of evidence.'),
 dict(key='king',title='If I Were King',slug='If-I-Were-King',player='king-player.pdf',hints='king-hints.pdf',solution='king-solution.pdf',instructions=4,opening=1,story_after=[13,17,22],evidence=list(range(5,23)),start='K01-K03',catalog='archive folio 3',work='archive folios 23-25',h_offset=0,s_offset=0,solution_cover=True,first_evidence=5,extra='The case includes bereavement, a reported childhood death, and family separation. Apply the invented settlement in K03 and the case bounds in K18.'),
 dict(key='ashcombe',title='The Last Ashcombe',slug='The-Last-Ashcombe',player='ashcombe-player.pdf',hints='ashcombe-hints.pdf',solution='ashcombe-solution.pdf',instructions=2,opening=2,story_after=[8,16,21],evidence=list(range(5,22)),start='E01-E03',catalog='archive folio 4',work='archive folios 22-25',h_offset=0,s_offset=0,solution_cover=False,first_evidence=5,extra='Apply the fictional settlement, not external inheritance law. Determine entitlement at 6:15 a.m. on 20 September 1913. Petitioners are not an exhaustive candidate set.'),
]

def plain(s):
    return s.replace('\u2011','-').replace('\u2013','-').replace('\u2014','-')

def load_story(key):
    txt=(Path(__file__).parent/'stories'/f'{key}.md').read_text()
    result={}
    for section in re.split(r'^## ',txt,flags=re.M)[1:]:
        first,body=section.split('\n',1)
        k,title,trigger=first.split('|')
        result[k]={'title':title,'trigger':trigger,'body':[plain(p.strip()) for p in body.strip().split('\n\n') if p.strip()]}
    return result

def story_pdf(case, section, label):
    buf=BytesIO()
    doc=SimpleDocTemplate(buf,pagesize=(612,792),leftMargin=51,rightMargin=51,topMargin=55,bottomMargin=49)
    story_style=ParagraphStyle('story',parent=STYLE,leading=14.8,spaceAfter=3.5)
    story_head=ParagraphStyle('story-head',parent=HEAD,fontSize=23,leading=27,spaceAfter=13)
    flow=[Paragraph(escape('AFTER THE CASE' if label=='A' else 'THE STORY CONTINUES'),SUB),Paragraph(escape(section['title']),story_head),Paragraph(escape(section['trigger']),SMALL)]
    for p in section['body']: flow.append(Paragraph(escape(p),story_style))
    def decor(c,d):
        c.setFillColor(MUTED);c.setFont('SansBold',8);c.drawString(55,756,case['title'].upper())
        c.setStrokeColor(ACCENT);c.setLineWidth(.5);c.line(55,48,557,48)
        c.setFont('Sans',7.3);c.drawString(55,34,'NARRATIVE EDITION 2.0  /  SEPTEMBER 2026')
        c.drawRightString(557,34,f'{label}-{d.page}')
    doc.build(flow,onFirstPage=decor,onLaterPages=decor)
    return fitz.open(stream=buf.getvalue(),filetype='pdf')

def one_page(case, title, paragraphs, label='READ FIRST', footer=''):
    b=BytesIO();c=canvas.Canvas(b,pagesize=(612,792))
    c.setFillColor(MUTED);c.setFont('SansBold',8);c.drawString(52,752,case['title'].upper())
    y=717
    for text,sty in [(label,SUB),(title,HEAD)]+[(s,STYLE) for s in paragraphs]:
        p=Paragraph(text,sty);_,h=p.wrap(508,900);p.drawOn(c,52,y-h);y-=h+sty.spaceAfter
    if y<65: raise RuntimeError(f'Page overflow: {case["key"]} / {title}: {y}')
    c.setStrokeColor(ACCENT);c.setLineWidth(.5);c.line(52,48,560,48)
    c.setFillColor(MUTED);c.setFont('Sans',7.2);c.drawString(52,34,'NARRATIVE EDITION 2.0  /  SEPTEMBER 2026');c.drawRightString(560,34,footer)
    c.showPage();c.save();return fitz.open(stream=b.getvalue(),filetype='pdf')

def instructions(case, count):
    extra=case['extra']
    pars=[
      '<b>Print the Player PDF in full.</b> This edition contains '+str(count)+' pages, including its cover and interleaved story. Use US Letter, portrait, actual size / 100%; on A4, use Fit. Grayscale is sufficient. Single-sided lets you spread the records out; duplex uses the long edge. Keep the separate hints and sealed solution away from the player stack.',
      '<b>Follow the printed archive folios.</b> Existing page references mean the numbers labeled ARCHIVE in the footers, which remain stable. New story leaves use S0-S3. They make the PDF positions different from the archive numbers. Use the bookmarks or clickable catalog to find a page on screen.',
      '<b>Begin with the opening scene and brief.</b> Read '+case['start']+' and choose your next record through '+case['catalog']+'. Each later scene names the records to read first. In a nonlinear search, return to that scene after you have examined its records; scene order does not prove a connection.',
      '<b>Let the records carry the proof.</b> The new scenes dramatize the people around these papers. They are fictional narrative, not additional archival exhibits. A character can be mistaken. Names, dates, parents, addresses, source references, and the supplied rules establish the case; sympathy does not.',
      '<b>Make your case.</b> Use '+case['work']+'. Cite exhibit codes and exact fields, test alternatives, and leave unsupported matters open. Everyone investigates; no host, internet, cutting, or outside research is required. Use hints only when needed; open the solution after answering all final questions.',
      escape(extra)
    ]
    return one_page(case,'Read the people. Test the papers.',pars,footer=f'ARCHIVE {case["instructions"]:02}')

def update_footer(page, label):
    # Only the footer band is changed; all evidence above y=741 is retained.
    page.add_redact_annot(fitz.Rect(0,741,612,792),fill=(1,1,1))
    page.apply_redactions(images=0,graphics=0)
    page.draw_line((49,744),(563,744),color=(.48,.52,.48),width=.35)
    page.insert_text((49,760),'NARRATIVE EDITION 2.0 / '+label,fontname='helv',fontsize=7.2,color=(.26,.3,.28))

def add_original(out, src, i, folio, prefix='ARCHIVE'):
    out.insert_pdf(src,from_page=i,to_page=i,links=False,annots=False)
    update_footer(out[-1], f'{prefix} {folio:02}')

def restore_links(src,out,mapping):
    for old,new in mapping.items():
        for l in src[old].get_links():
            if l['kind']==fitz.LINK_GOTO and l.get('page') in mapping:
                out[new].insert_link({'kind':fitz.LINK_GOTO,'from':l['from'],'page':mapping[l['page']],'to':l.get('to',fitz.Point(0,0))})
            elif l['kind']==fitz.LINK_NAMED and str(l.get('page','')).isdigit():
                # ReportLab /Fit destinations are exposed by MuPDF as 1-based
                # page strings, rather than zero-based LINK_GOTO integers.
                dest=int(l['page'])-1
                if dest in mapping:
                    out[new].insert_link({'kind':fitz.LINK_GOTO,'from':l['from'],'page':mapping[dest],'to':fitz.Point(0,0)})
            elif l['kind']==fitz.LINK_URI:
                out[new].insert_link({'kind':fitz.LINK_URI,'from':l['from'],'uri':l['uri']})

def label_doc(doc, labels):
    doc.set_page_labels([{'startpage':i,'prefix':s,'style':'','firstpagenum':1} for i,s in enumerate(labels)])

def save(doc,path,case,kind):
    doc.set_metadata({'title':case['title']+' - '+kind+' - Narrative edition 2.0','author':'Family Papers Case Files','subject':'Fictional genealogy investigation; expanded character narrative','keywords':'genealogy, printable mystery, narrative edition 2.0','creator':'Family Papers narrative edition builder'})
    doc.save(path,garbage=4,deflate=True)
    return path

def build_player(case, originals=None):
    src=fitz.open(SRC/case['player']) if originals is None else originals
    story=load_story(case['key'])
    inserts={case['opening']:('opening','S0')}
    inserts.update({pg:(f's{j}',f'S{j}') for j,pg in enumerate(case['story_after'],1)})
    inserts_docs={pos:story_pdf(case,story[k],label) for pos,(k,label) in inserts.items()}
    count=len(src)+sum(len(d) for d in inserts_docs.values())
    out=fitz.open();mapping={};labels=[];toc=[];story_locations=[]
    for i in range(len(src)):
        mapping[i]=len(out);folio=i+1
        if folio==case['instructions']:
            out.insert_pdf(instructions(case,count),links=False)
        else:
            add_original(out,src,i,folio)
        labels.append(str(folio))
        if folio in inserts:
            k,label=inserts[folio];d=inserts_docs[folio]
            story_locations.append({'key':k,'label':label,'title':story[k]['title'],'after_archive_folio':folio,'pdf_first':len(out)+1,'pages':len(d),'prerequisites':story[k]['trigger'],'words':sum(len(x.split()) for x in story[k]['body'])})
            toc.append([1,label+' / '+story[k]['title'],len(out)+1])
            out.insert_pdf(d,links=False);labels += [label+'-'+str(n+1) for n in range(len(d))]
    restore_links(src,out,mapping)
    # Use ordinary folio bookmarks, so no answer is advertised by a bookmark label.
    for i,new in mapping.items(): toc.append([1,'Archive '+str(i+1).zfill(2),new+1])
    out.set_toc(sorted(toc,key=lambda x:x[2]));label_doc(out,labels)
    path=(OUT if originals is None else TMP)/(case['slug']+'-Player.pdf');save(out,path,case,'Player')
    verification=[]
    # Pixel identity above the footer establishes that the original record image and
    # every clue-bearing field stayed intact. Links and footer are checked separately.
    for folio in case['evidence']:
        # The mask antialiases one row at y=740. All record content ends above it.
        rect=fitz.Rect(0,0,612,740)
        a=src[folio-1].get_pixmap(matrix=fitz.Matrix(1,1),clip=rect,alpha=False).samples
        b=out[mapping[folio-1]].get_pixmap(matrix=fitz.Matrix(1,1),clip=rect,alpha=False).samples
        if a!=b: raise RuntimeError(f'Evidence pixels changed: {case["key"]} folio {folio}')
        verification.append(folio)
    rec={'case':case['key'],'title':case['title'],'player':path.name,'pages':len(out),'story':story_locations,'original_to_pdf':{str(k+1):v+1 for k,v in mapping.items()},'unchanged_evidence_folios':verification,'original_evidence_pixel_match':True,'source_sha256':hashlib.sha256((SRC/case['player']).read_bytes()).hexdigest() if originals is None else None}
    return path,rec

def build_hints(case):
    src=fitz.open(SRC/case['hints']);out=fitz.open();labels=[]
    guide=one_page(case,'Use one hint at a time.',[
      'Return to the records as soon as a hint gives you a next step. The original hint levels and exhibit references remain unchanged in this edition.',
      'If a scene has made you certain about somebody, ask which record supports that certainty. Caring about a person, distrusting them, or finding their explanation plausible is not a substitute for a link in the evidence.',
      'The story can leave a motive complicated while the record answers a factual question. You are allowed to reach a firm identification and still disagree about the person involved.',
      'The following pages retain their original hint folios. Read progressively. Keep the separate sealed solution closed until you have committed your answer.'
    ],label='OPTIONAL HELP',footer='HINT GUIDE')
    out.insert_pdf(guide);labels.append('Help')
    for i in range(len(src)):
        add_original(out,src,i,i+1+case['h_offset'],'HINT');labels.append('H'+str(i+1+case['h_offset']))
    out.set_toc([[1,'Hint guide',1]]+[[1,'Hint folio '+str(i+1+case['h_offset']),i+2] for i in range(len(src))]);label_doc(out,labels)
    return save(out,OUT/(case['slug']+'-Hints.pdf'),case,'Optional hints')

def build_solution(case):
    src=fitz.open(SRC/case['solution']);out=fitz.open();labels=[]
    gate=one_page(case,'Stop here until you commit.',[
      'This file reveals the investigation, the identities, and the ending. Keep it separate from the player packet.',
      'Before continuing, write your conclusion, cite the records that support it, and name an uncertainty the file does not resolve.',
      'Read the evidence-cited solution first. The expanded aftermath follows the original ending. It develops the human consequences; it does not supply a clue needed to solve the case.',
      'A blank reverse follows this cover so the first answer starts on a fresh sheet when this file is printed on both sides.'
    ],label='SEALED SOLUTION',footer='SEALED')
    out.insert_pdf(gate);labels.append('Sealed')
    blank=one_page(case,'The answer is overleaf.',[
      'Keep this file closed until your written reconstruction is complete.'
    ],label='SPOILER BARRIER',footer='SEALED REVERSE')
    out.insert_pdf(blank);labels.append('Sealed-back')
    start=1 if case['solution_cover'] else 0
    mapping={}
    for i in range(start,len(src)):
        mapping[i]=len(out);add_original(out,src,i,i+1+case['s_offset'],'SOLUTION');labels.append('R'+str(i+1+case['s_offset']))
    restore_links(src,out,mapping)
    after=load_story(case['key'])['aftermath'];a=story_pdf(case,after,'A');ap=len(out)
    out.insert_pdf(a);labels += ['A-'+str(i+1) for i in range(len(a))]
    out.set_toc([[1,'Sealed solution',1],[1,'Evidence-cited answer',3],[1,'Expanded aftermath',ap+1]]);label_doc(out,labels)
    return save(out,OUT/(case['slug']+'-Sealed-Solution.pdf'),case,'Sealed solution')

def combine(case, paths, rec):
    docs=[fitz.open(p) for p in paths]
    # Two-page setup keeps the Player file's own first page on a fresh duplex sheet.
    starts=[];n=2
    for d in docs:
        if n%2:n+=1
        starts.append(n+1);n+=len(d)
    if n%2:n+=1
    rows=[f'<b>{name}:</b> PDF positions {st}-{st+len(d)-1} ({len(d)} pages).'
          for name,st,d in zip(['Player packet','Optional hints','Sealed solution'],starts,docs)]
    intro=one_page(case,'Print and separate before play.',[
        'This complete edition contains '+str(n)+' PDF pages. The ranges below are <b>physical PDF positions</b>, not the archive folios retained within the case.',
        *rows,
        'For the simplest setup, print the separate Player, Hints, and Sealed Solution PDFs. If using this file, separate the protected sections using these ranges before distributing the player packet. The sections start on fresh duplex sheets.',
        'Print US Letter at 100%, or A4 with Fit; grayscale is sufficient. Read the player instructions for the archive folios, story leaves, and investigation. All characters and records are fictional.'
    ],label='COMPLETE NARRATIVE EDITION',footer='SETUP 1')
    out=fitz.open();out.insert_pdf(intro)
    out.insert_pdf(one_page(case,'The player file begins next.',[
       'Keep the hints and solution separate before anyone starts reading. This reverse protects the first player sheet when printing duplex.'
    ],label='PRINT SETUP',footer='SETUP 2'))
    toc=[[1,'Print and separate',1]];labels=['Setup-1','Setup-2']
    for name,st,d in zip(['Player packet','Optional hints','Sealed solution'],starts,docs):
        if len(out)%2:
            out.new_page(width=612,height=792);labels.append('Blank')
        assert len(out)+1==st
        off=len(out);out.insert_pdf(d)
        toc.append([1,name,off+1])
        for level,title,page in d.get_toc():toc.append([2,title,page+off])
        labels += [d[i].get_label() for i in range(len(d))]
    if len(out)%2:out.new_page(width=612,height=792);labels.append('Blank')
    out.set_toc(toc);label_doc(out,labels)
    rec['complete_pages']=len(out);rec['complete_sections']={k:{'first':st,'last':st+len(d)-1} for k,st,d in zip(['player','hints','solution'],starts,docs)}
    return save(out,OUT/(case['slug']+'-Complete.pdf'),case,'Complete edition')

def preview(case, player, rec):
    d=fitz.open(player);out=fitz.open()
    cover=one_page(case,'A family story under pressure.',[
       'Read an opening scene and one genuine exhibit from the expanded narrative edition. This preview contains no solution or hidden identity disclosure.',
       '<b>Inside the complete game:</b> a sustained character story, an archive of inspectable records, working pages, progressive hints, an evidence-cited solution, and an expanded aftermath.',
       'Play alone or investigate together. Every required clue is in the supplied papers. Print in grayscale or use the PDF bookmarks and catalog. No host or outside research is needed.',
       '<b>Player file:</b> '+str(rec['pages'])+' pages. Preview pages are selected excerpts; their archive and story labels match the full edition.'
    ],label='SPOILER-FREE PREVIEW',footer='PREVIEW')
    out.insert_pdf(cover)
    op=next(x for x in rec['story'] if x['key']=='opening')
    out.insert_pdf(d,from_page=op['pdf_first']-1,to_page=op['pdf_first']+op['pages']-2,links=False)
    i=rec['original_to_pdf'][str(case['first_evidence'])]-1
    out.insert_pdf(d,from_page=i,to_page=i,links=False)
    out.set_toc([[1,'About this case',1],[1,'Opening scene',2],[1,'First exhibit',len(out)]]);
    return save(out,OUT/(case['slug']+'-Preview.pdf'),case,'Spoiler-free preview')

def earlier_eleanor(base, source, slug, player_end, hints_start, sol_start, scenes, evidence, extra):
    case={**base,'player':source,'slug':slug,'story_after':scenes,'opening':2,'evidence':evidence,'extra':extra}
    original=fitz.open(SRC/source)
    pl=fitz.open();pl.insert_pdf(original,from_page=0,to_page=player_end-1)
    # Use the same builder and preserve that edition's evidence, search system, and questions.
    p,rec=build_player(case,pl)
    d=fitz.open(p);out=fitz.open();out.insert_pdf(d);labels=[d[i].get_label() for i in range(len(d))]
    toc=d.get_toc();mapold={int(k)-1:v-1 for k,v in rec['original_to_pdf'].items()}
    starts={}
    for section,start,end in [('hints',hints_start-1,sol_start-2),('solution',sol_start-1,len(original)-1)]:
        if len(out)%2:
            out.new_page(width=612,height=792);labels.append('Blank')
        starts[section]=len(out)+1;toc.append([1,'Optional hints' if section=='hints' else 'Sealed solution',len(out)+1])
        # A one-page warning plus blank reverse protects the revised book's hint entry.
        if section=='hints':
            gate=one_page(case,'Pause before the hints.',[
                'Complete your own reconstruction first. These original hints belong to this edition and refer to its unchanged document codes and archive folios.',
                'A sympathetic character can be wrong. Use the hint only to find another record or test a connection.'
            ],label='OPTIONAL HELP',footer='HINT GATE')
            out.insert_pdf(gate);labels.append('Hint-gate');out.new_page(width=612,height=792);labels.append('Blank')
        for i in range(start,end+1):
            mapold[i]=len(out);add_original(out,original,i,i+1,'HINT' if section=='hints' else 'SOLUTION');labels.append(str(i+1))
    after=story_pdf(case,load_story('eleanor')['aftermath'],'A');toc.append([1,'Expanded aftermath',len(out)+1]);out.insert_pdf(after);labels += ['A-'+str(i+1) for i in range(len(after))]
    # Rebuild all archive links from the original, including the nonlinear catalog.
    for pg in out:
        for link in pg.get_links():pg.delete_link(link)
    restore_links(original,out,mapold)
    out.set_toc(toc);label_doc(out,labels)
    # Replace folio 2 with the combined edition's actual physical print ranges.
    insidx=mapold[1]
    text=[
       f'<b>Expanded edition:</b> {len(out)} physical PDF pages. Player material: PDF positions 1-{len(d)}. Hints begin at position {starts["hints"]}; sealed solution begins at position {starts["solution"]}. Separate the protected sections before play. They start on fresh duplex sheets.',
       'Print US Letter at 100%, or A4 with Fit; grayscale is sufficient. Duplex uses the long edge. You need a pencil or separate notes. No host or internet is required.',
       '<b>Page references mean archive folios.</b> The printed ARCHIVE numbers preserve every reference from the original edition. Added story leaves use S0-S3; their numbers differ from physical PDF positions. Use bookmarks or the clickable catalog to navigate.',
       'Read the opening scene and brief, then follow the archive. Each later scene names the records to read first. The scenes dramatize encounters around the papers; they are not extra archival exhibits. Derive your answer from the records, and distinguish a person\'s claim from proof.',
       escape(extra),
       'Answer every final question and cite the evidence before opening the solution. The expanded aftermath follows the original ending.'
    ]
    # Redact this instruction page only, then overlay replacement content in place.
    page=out[insidx];page.add_redact_annot(page.rect,fill=(1,1,1));page.apply_redactions(images=2,graphics=2)
    page.show_pdf_page(page.rect,one_page(case,'Read, investigate, then unseal.',text,footer='ARCHIVE 02'),0)
    path=OUT/(slug+'.pdf');save(out,path,case,'Expanded complete edition')
    p.unlink() # This is an alternate complete edition, not a fourth customer case.
    rec.update({'player':None,'complete':path.name,'complete_pages':len(out),'complete_sections':starts})
    return rec

def main(selected='all'):
    reports=[]
    for case in [c for c in CASES if selected in ('all',c['key'])]:
        p,rec=build_player(case);h=build_hints(case);s=build_solution(case)
        c=combine(case,[p,h,s],rec);v=preview(case,p,rec)
        rec['files']={k:x.name for k,x in zip(['player','hints','solution','complete','preview'],[p,h,s,c,v])}
        reports.append(rec)
        print(case['title'],rec['pages'],'player pages;',rec['complete_pages'],'complete pages',flush=True)
    if selected in ('all','eleanor'):
        reports.append(earlier_eleanor(CASES[0],'eleanor-book.pdf','Eleanor-Hart-Illustrated-Book',41,42,44,[12,20,24],list(range(5,37)),
            'This illustrated edition retains sixteen designed records with their plain reading copies and eight final questions. Read either rendering of a record; both carry the same evidence.'))
        reports.append(earlier_eleanor(CASES[0],'eleanor-archive.pdf','Eleanor-Hart-200-Entry-Archive',70,71,75,[22,19,27],list(range(13,61)),
            'This edition preserves the 200-entry searchable paper archive, its sixteen core documents (including two marriage entries), six deductions, and surrounding search records. Use the catalog rather than reading every record in order. Scene prerequisites refer to EH document numbers.'))
    (ROOT/'build-report.json').write_text(json.dumps(reports,indent=2))
    print('Built',len(list(OUT.glob('*.pdf'))),'PDFs',flush=True)

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--case',default='all',choices=['all']+[c['key'] for c in CASES])
    main(ap.parse_args().case)
